# UI Design and Development - Chapter 009 (TypeScript)

[More Info](https://github.com/metacube-manthan-rajoria/Assignments/tree/main/003%20-%20UI%20Design%20%26%20Development/Chapter%20009%20-%20TypeScript)

# Usage
Run the following commands in terminal
```js
npm i
npx tsc
```
Then host the index.html on any port or just open the file.