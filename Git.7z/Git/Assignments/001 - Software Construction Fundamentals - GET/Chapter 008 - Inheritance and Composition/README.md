# Inheritance and Composition

[Click to open the Original Problem Document](https://docs.google.com/document/d/1M9DlOag23cWvGAcKRP5gZzXPcN9wZ5UU/edit)

### Organization
- [My Solution (Annotated Markdown File)](./Assignment.md)
- [My Solution (Raw Java File)](./Organization.java)
