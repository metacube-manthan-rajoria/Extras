# Invariants in Design

[Click to open the Original Problem Document](https://docs.google.com/document/d/16WDN6R_cWgEU5_6xpL57gN7uFersCPe2dLH8XMV8LRw/edit)

### Matrix
- [My Solution (Annotated Markdown File)](./Assignment.md)
- [My Solution (Raw Java File)](./Matrix.java)
