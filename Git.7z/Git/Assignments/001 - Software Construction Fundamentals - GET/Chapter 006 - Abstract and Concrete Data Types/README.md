# Abstract Data Type

[Click to open the Original Problem Document](https://docs.google.com/document/d/1Mf76p9SK3AEKxBd0tfej3z4wuLdfyF90M1IS10GLJVE)

### IntSet
- [My Solution (Annotated Markdown File)](./Assignment%201/Assignment.md)
- [My Solution (Raw Java File)](./Assignment%201/Assignment.java)

### Polynomial Operation
- [My Solution (Annotated Markdown File)](./Assignment%202/Assignment.md)
- [My Solution (Raw Java File)](./Assignment%202/Assignment.java)
