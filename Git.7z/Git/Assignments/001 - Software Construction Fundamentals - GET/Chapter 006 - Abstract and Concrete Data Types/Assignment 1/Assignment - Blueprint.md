# This file Is only for planning and trying out rough ideas.

```java

```
