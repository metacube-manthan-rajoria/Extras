# Exception Handling

[Click to open the Original Problem document](https://docs.google.com/document/d/1vsNu3XKGLQWYvktlZBraDTL68SeTL4xN/edit?usp=sharing&ouid=103722936288136956473&rtpof=true&sd=true)

### Hex Calc
- [My Solution (Annotated Markdown File)](./Assignment%201/Assignment.md)
- [My Solution (Raw Java File)](./Assignment%201/Assignment.java)

### Job Scheduler
- [My Solution (Annotated Markdown File)](./Assignment%202/Assignment.md)
- [My Solution (Raw Java File)](./Assignment%202/Assignment.java)

