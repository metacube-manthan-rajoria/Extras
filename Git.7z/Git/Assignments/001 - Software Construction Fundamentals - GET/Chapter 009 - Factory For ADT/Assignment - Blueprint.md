# This file Is only for planning and trying out rough ideas.

angle in radian = angle in degree * Pi / 180


```java

```
