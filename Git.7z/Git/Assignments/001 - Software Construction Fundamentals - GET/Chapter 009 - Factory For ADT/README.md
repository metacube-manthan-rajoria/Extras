# Factory Method

[Click to open the Original Problem Document](https://docs.google.com/document/d/1MNOAu3djNLjVWFuhWxF09Uu8pXenGwKH/edit)

### Shapes Factory
- [My Solution (Annotated Markdown File)](./Assignment.md)
- [My Solution (Raw Java File)](./Main.java)
