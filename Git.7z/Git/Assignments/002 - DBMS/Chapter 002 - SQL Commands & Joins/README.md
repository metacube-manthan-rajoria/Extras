[Click to open the Original Problem Document](https://docs.google.com/document/d/1EQoeXlCoTQ6dsvhv1xP7iZAhW-M0WdrfIs056XOnMzM/edit)

### StoreFront Database Creation
- [My Solution (Annotated Markdown File)](./Assignment.md)
- [My Solution (SQL File) - Database Creation](./StoreFront_01_Creation.sql)
- [My Solution (SQL File) - Database Data Insertion](./StoreFront_02_Data_Insertion.sql)
- [My Solution (SQL File) - Database Queries](./StoreFront_03_Queries.sql)