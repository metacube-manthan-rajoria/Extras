[Click to open the Original Problem Document](https://docs.google.com/document/d/1jwqidxQxjZ0ZVbvS-_jrKthqB4YWnB1n3cekXnK_py0/edit)

### StoreFront Database Creation
- [My Solution (Annotated Markdown File)](./Assignment.md)
- [My Solution (App.java) - Entry Point](https://github.com/metacube-manthan-rajoria/Assignments/blob/main/002%20-%20DBMS/Chapter%20003%20-%20JDBC/JDBC/app/src/main/java/jdbc/App.java)